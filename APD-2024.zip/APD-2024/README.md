# APD - schelete

Structură
- laboratoare - director pentru scheletele de laboratoare, fiecare laborator cu propriul său director (exemplu: laboratorul 1 - lab01)
- teme - director pentru scheletele de teme, fiecare tema cu propriul său director (exemplu: tema 1 - tema1)
